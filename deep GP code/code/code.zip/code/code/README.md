# README #

Results are in the jupyter-notebook and Rmd file
